

from models import customer_master
from repo import Customer_master_Repository


def customer_data(data):
    print("=============",data)

    data = customer_master(data["Name"],data["Contact"],data["Address"],data["Nearby Landmark"])
    print("in service ",data)
    resp = Customer_master_Repository.customer_master(data)
    print("--------------",resp)
    return resp
