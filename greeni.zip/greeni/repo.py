

from database_config import db_session, engine
from sqlalchemy.orm import sessionmaker
from models import *

Session = sessionmaker(bind=engine)
session = Session()


class Customer_master_Repository:
    def customer_master(data):
        # result = session.query(customer_master).filter(customer_master.name == data.name).first()
        # db_session.add(data)
        # db_session.commit()
        # if not result:
        db_session.add(data)
        db_session.commit()
            # return data.resp
        # else:
        #     print("Already Exist")
        #     return result.resp
