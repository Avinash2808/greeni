
from flask import Flask,jsonify,request,render_template
import requests
app = Flask(__name__)
from database_config import init_db
from repo import Customer_master_Repository
from services import customer_data

@app.route('/greeni')
def hello_world():
    # return ("Hello Greeni Yay the app is working")
    return render_template ("index.html")


@app.route('/greeni_data',methods=["POST"])
def greeni_data():
    data= request.get_json()
    print(data)
    if  data["Name"]=="" or data["Contact"]=="" or data["Address"]=="" or data["Nearby Landmark"] == "":
        return jsonify({"status":"missing Field"})
    else:
        data= customer_data(data)
        print("==== in main",data)
        return jsonify({"data":data})

if __name__ == '__main__':
    init_db()
    app.run(debug=True)

