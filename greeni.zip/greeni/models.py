

from sqlalchemy import *
from database_config import Base

class customer_master(Base):
    __tablename__ = 'customer_masters'
    id = Column(Integer, primary_key=True)
    name = Column(String(50),unique=False)
    contact = Column(String(50),unique=False)
    address = Column(String(50),unique=False)
    landmark = Column(String(50),unique=False)

    # email = Column(String(120), unique=True)

    def __init__(self, name = None,contact=None,address=None,landmark=None):
        self.name = name
        self.contact = contact
        self.address=address
        self.landmark = landmark
        # self.email = email

    # def __repr__(self):
    #     return '<User %r>' % (self.name)


class order_master(Base):
    __tablename__ = 'order_masters'
    id = Column(Integer, primary_key=True,autoincrement=True)
    name = Column(String(50))
    order = Column(String(100), unique=True)
    # address = Column(String(50))
    # landmark = Column(String(50))

    # email = Column(String(120), unique=True)

    def __init__(self, name = None,order=None):
        self.name = name
        # self.contact = contact
        self.order=order
        # self.landmark = landmark
        # self.email = email

    def __repr__(self):
        return '<User %r>' % (self.name)
